package TurboDesk;

import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.sql.*;
import java.util.*;
import java.util.Date;
import javax.swing.*;
import com.toedter.calendar.JCalendar;

public class NuevaCita extends JFrame {

    private JTextField txtNombre;
    private JTextField txtApellidos;
    private JCalendar calendar;

    public NuevaCita() {
    	setIconImage(Toolkit.getDefaultToolkit().getImage(NuevaCita.class.getResource("/Fotos/fondo.jpg")));
        // Configuración inicial de la ventana
        setTitle("Nueva Cita");
        setSize(746, 514);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Intentar cargar el icono de la ventana
        try {
            URL iconURL = getClass().getResource("/TurboDesk/calendario.jpg");
            if (iconURL != null) {
                setIconImage(Toolkit.getDefaultToolkit().getImage(iconURL));
            } else {
                System.err.println("No se pudo encontrar la imagen: /Fotos/calendario.jpg");
            }
        } catch (Exception e) {
            System.err.println("Error al cargar el icono: " + e.getMessage());
        }

        // Fondo
        JLabel fondo = new JLabel();
        fondo.setEnabled(false);
        fondo.setBounds(0, 0, 768, 491);
        fondo.setIcon(new ImageIcon("C:\\Users\\Alumno1\\Downloads\\citas (1).jpg"));
        try {
            URL fondoURL = getClass().getResource("/Fotos/fondo.jpg");
            if (fondoURL != null) {
                fondo.setIcon(new ImageIcon(fondoURL));
            } else {
                System.err.println("No se pudo encontrar la imagen: /Fotos/fondo.jpg");
                fondo.setBackground(Color.LIGHT_GRAY);
                fondo.setOpaque(true);
            }
        } catch (Exception e) {
            System.err.println("Error al cargar el fondo: " + e.getMessage());
            fondo.setBackground(Color.LIGHT_GRAY);
            fondo.setOpaque(true);
        }
        getContentPane().setLayout(null);
        getContentPane().add(fondo);

        // Nombre
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setFont(new Font("Arial", Font.BOLD, 14));
        lblNombre.setBounds(50, 50, 100, 30);
        fondo.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(150, 50, 200, 30);
        fondo.add(txtNombre);

        // Apellidos
        JLabel lblApellidos = new JLabel("Apellidos:");
        lblApellidos.setFont(new Font("Arial", Font.BOLD, 14));
        lblApellidos.setBounds(50, 100, 100, 30);
        fondo.add(lblApellidos);

        txtApellidos = new JTextField();
        txtApellidos.setBounds(150, 100, 200, 30);
        fondo.add(txtApellidos);

        // Calendario
        calendar = new JCalendar();
        calendar.setBounds(50, 150, 300, 200);
        fondo.add(calendar);

        // Botón Confirmar
        JButton btnConfirmar = new JButton("Confirmar");
        btnConfirmar.setBackground(new Color(51, 255, 51));
        btnConfirmar.setFont(new Font("Arial", Font.BOLD, 12));
        btnConfirmar.setBounds(475, 180, 187, 40);
        btnConfirmar.addActionListener(e -> confirmarCita());
        fondo.add(btnConfirmar);

        // Botón Listar Citas
        JButton btnListarCitas = new JButton("Listar Citas");
        btnListarCitas.setBackground(new Color(135, 206, 235));
        btnListarCitas.setFont(new Font("Arial", Font.BOLD, 12));
        btnListarCitas.setBounds(475, 230, 187, 40);
        btnListarCitas.addActionListener(e -> listarCitas());
        fondo.add(btnListarCitas);

        // Botón Eliminar Cita
        JButton btnEliminarCita = new JButton("Eliminar Cita");
        btnEliminarCita.setBackground(new Color(255, 69, 0));
        btnEliminarCita.setFont(new Font("Arial", Font.BOLD, 12));
        btnEliminarCita.setBounds(475, 280, 187, 40);
        btnEliminarCita.addActionListener(e -> eliminarCita());
        fondo.add(btnEliminarCita);

        // Botón Volver
        JButton btnVolver = new JButton("Volver al Menú");
        btnVolver.setBackground(new Color(204, 153, 51));
        btnVolver.setFont(new Font("Arial", Font.BOLD, 12));
        btnVolver.setBounds(475, 330, 187, 40);
        btnVolver.addActionListener(e -> {
            dispose();
            new MenuInicio().setVisible(true);
        });
        fondo.add(btnVolver);
    }

    private void confirmarCita() {
        String nombre = txtNombre.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        Date fecha = calendar.getDate();

        if (nombre.isEmpty() || apellidos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.");
            return;
        }

        if (fecha == null) {
            JOptionPane.showMessageDialog(this, "Por favor, selecciona una fecha.");
            return;
        }

        guardarCitaEnBD(nombre, apellidos, fecha);
    }

    private void guardarCitaEnBD(String nombre, String apellidos, Date fecha) {
        try {
            // Buscar o crear cliente
            int clienteId = obtenerOInsertarCliente(nombre, apellidos);
            // Mostrar diálogo para seleccionar coche
            int cocheId = seleccionarCoche();
            if (cocheId == -1) {
                JOptionPane.showMessageDialog(null, "No se seleccionó un coche.");
                return;
            }

            ConexionMySQL conexion = new ConexionMySQL("root", "", "taller_repuestos");
            conexion.conectar();
            String sql = "CALL RegistrarCita(?, ?, ?)";
            CallableStatement cstmt = conexion.getConexion().prepareCall(sql);
            cstmt.setInt(1, clienteId);
            cstmt.setInt(2, cocheId);
            cstmt.setDate(3, new java.sql.Date(fecha.getTime()));
            cstmt.executeUpdate();
            cstmt.close();
            conexion.desconectar();
            JOptionPane.showMessageDialog(null, "Cita registrada correctamente.");
            dispose();
            new MenuInicio().setVisible(true);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al guardar la cita: " + ex.getMessage());
        }
    }

    private int obtenerOInsertarCliente(String nombre, String apellidos) throws SQLException {
        ConexionMySQL conexion = new ConexionMySQL("root", "", "taller_repuestos");
        conexion.conectar();
        // Buscar cliente por nombre y apellidos
        String sqlSelect = "SELECT id FROM clientes WHERE nombre = ? AND apellidos = ?";
        PreparedStatement pstmt = conexion.getConexion().prepareStatement(sqlSelect);
        pstmt.setString(1, nombre);
        pstmt.setString(2, apellidos);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            int clienteId = rs.getInt("id");
            rs.close();
            pstmt.close();
            conexion.desconectar();
            return clienteId;
        }
        rs.close();
        pstmt.close();

        // Insertar nuevo cliente
        String correo = nombre.toLowerCase() + "." + apellidos.toLowerCase().replace(" ", "") + "@gmail.com";
        String sqlInsert = "INSERT INTO clientes (nombre, apellidos, correo) VALUES (?, ?, ?)";
        pstmt = conexion.getConexion().prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);
        pstmt.setString(1, nombre);
        pstmt.setString(2, apellidos);
        pstmt.setString(3, correo);
        pstmt.executeUpdate();
        rs = pstmt.getGeneratedKeys();
        rs.next();
        int clienteId = rs.getInt(1);
        rs.close();
        pstmt.close();
        conexion.desconectar();
        return clienteId;
    }

    private int seleccionarCoche() throws SQLException {
        ConexionMySQL conexion = new ConexionMySQL("root", "", "taller_repuestos");
        conexion.conectar();
        String sql = "SELECT COCHE_ID, MODELO, MARCA FROM coches";
        ResultSet rs = conexion.ejecutarSelect(sql);
        ArrayList<String> coches = new ArrayList<>();
        ArrayList<Integer> cocheIds = new ArrayList<>();
        while (rs.next()) {
            cocheIds.add(rs.getInt("COCHE_ID"));
            coches.add("ID: " + rs.getInt("COCHE_ID") + " - " + rs.getString("MODELO") + " (" + rs.getString("MARCA") + ")");
        }
        rs.close();
        conexion.desconectar();

        if (coches.isEmpty()) {
            return -1;
        }

        JComboBox<String> comboCoches = new JComboBox<>(coches.toArray(new String[0]));
        int opcion = JOptionPane.showConfirmDialog(this, comboCoches, "Selecciona un coche", JOptionPane.OK_CANCEL_OPTION);
        if (opcion == JOptionPane.OK_OPTION) {
            return cocheIds.get(comboCoches.getSelectedIndex());
        }
        return -1;
    }

    private void listarCitas() {
        try {
            ConexionMySQL conexion = new ConexionMySQL("root", "", "taller_repuestos");
            conexion.conectar();
            String sql = "SELECT c.id, cl.nombre, cl.apellidos, co.MODELO, c.fecha " +
                         "FROM citas c " +
                         "JOIN clientes cl ON c.cliente_id = cl.id " +
                         "JOIN coches co ON c.coche_id = co.COCHE_ID";
            ResultSet rs = conexion.ejecutarSelect(sql);
            ArrayList<String> citas = new ArrayList<>();
            while (rs.next()) {
                citas.add("ID: " + rs.getInt("id") + " - " +
                          rs.getString("nombre") + " " + rs.getString("apellidos") +
                          ", Coche: " + rs.getString("MODELO") +
                          ", Fecha: " + rs.getDate("fecha"));
            }
            rs.close();
            conexion.desconectar();

            if (citas.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay citas registradas.");
            } else {
                JList<String> listaCitas = new JList<>(citas.toArray(new String[0]));
                JScrollPane scrollPane = new JScrollPane(listaCitas);
                JOptionPane.showMessageDialog(this, scrollPane, "Citas Registradas", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al listar citas: " + ex.getMessage());
        }
    }

    private void eliminarCita() {
        try {
            ConexionMySQL conexion = new ConexionMySQL("root", "", "taller_repuestos");
            conexion.conectar();
            String sql = "SELECT c.id, cl.nombre, cl.apellidos, co.MODELO, c.fecha " +
                         "FROM citas c " +
                         "JOIN clientes cl ON c.cliente_id = cl.id " +
                         "JOIN coches co ON c.coche_id = co.COCHE_ID";
            ResultSet rs = conexion.ejecutarSelect(sql);
            ArrayList<String> citas = new ArrayList<>();
            ArrayList<Integer> citaIds = new ArrayList<>();
            while (rs.next()) {
                citaIds.add(rs.getInt("id"));
                citas.add("ID: " + rs.getInt("id") + " - " +
                          rs.getString("nombre") + " " + rs.getString("apellidos") +
                          ", Coche: " + rs.getString("MODELO") +
                          ", Fecha: " + rs.getDate("fecha"));
            }
            rs.close();

            if (citas.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay citas para eliminar.");
                conexion.desconectar();
                return;
            }

            JList<String> listaCitas = new JList<>(citas.toArray(new String[0]));
            JScrollPane scrollPane = new JScrollPane(listaCitas);
            int opcion = JOptionPane.showConfirmDialog(this, scrollPane, "Selecciona una cita para eliminar",
                    JOptionPane.OK_CANCEL_OPTION);
            if (opcion == JOptionPane.OK_OPTION && listaCitas.getSelectedIndex() != -1) {
                int citaId = citaIds.get(listaCitas.getSelectedIndex());
                String sqlDelete = "DELETE FROM citas WHERE id = ?";
                PreparedStatement pstmt = conexion.getConexion().prepareStatement(sqlDelete);
                pstmt.setInt(1, citaId);
                pstmt.executeUpdate();
                pstmt.close();
                JOptionPane.showMessageDialog(this, "Cita eliminada correctamente.");
            }
            conexion.desconectar();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al eliminar cita: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new NuevaCita().setVisible(true));
    }
}