package TurboDesk;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Soporte extends JFrame {
    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtCorreo;
    private JTextArea txtMensaje;

    public Soporte() {
        // Establece el icono de la ventana
        setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Alumno1\\Pictures\\soporte.jpg"));

        setTitle("Soporte - TurboDesk");
        setSize(579, 429);
        setLocationRelativeTo(null); // Centra la ventana en pantalla
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null); // Layout absoluto para posicionar manualmente

        // Carga la imagen de fondo
        ImageIcon fondoIcon = new ImageIcon(getClass().getResource("/Fotos/soporte.jpg"));

        // Panel transparente para contener los campos y botones
        JPanel panelTransparente = new JPanel();
        panelTransparente.setLayout(null);
        panelTransparente.setBounds(0, 0, 600, 450);
        panelTransparente.setOpaque(false);

        // Campos y etiquetas
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 30, 100, 25);
        txtNombre = new JTextField();
        txtNombre.setBounds(150, 30, 200, 25);

        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setBounds(30, 70, 100, 25);
        txtApellido = new JTextField();
        txtApellido.setBounds(150, 70, 200, 25);

        JLabel lblCorreo = new JLabel("Correo Generado:");
        lblCorreo.setBounds(30, 110, 120, 25);
        txtCorreo = new JTextField();
        txtCorreo.setBounds(150, 110, 200, 25);
        txtCorreo.setEditable(false); // No editable

        JButton btnGenerar = new JButton("Generar Correo");
        btnGenerar.setBounds(150, 261, 150, 25);
        btnGenerar.addActionListener(e -> generarCorreo());

        JLabel lblMensaje = new JLabel("Mensaje:");
        lblMensaje.setBounds(30, 150, 100, 25);
        txtMensaje = new JTextArea();
        JScrollPane scroll = new JScrollPane(txtMensaje);
        scroll.setBounds(150, 150, 370, 100);

        JButton btnGuardar = new JButton("Guardar en BD");
        btnGuardar.setBounds(336, 261, 150, 30);
        btnGuardar.addActionListener(e -> guardarEnBD());

        JButton btnVolver = new JButton("Volver al Menú");
        btnVolver.setBounds(383, 341, 150, 30);
        btnVolver.addActionListener(e -> volverAlMenu());

        // Añadir componentes al panel transparente
        panelTransparente.add(lblNombre);
        panelTransparente.add(txtNombre);
        panelTransparente.add(lblApellido);
        panelTransparente.add(txtApellido);
        panelTransparente.add(lblCorreo);
        panelTransparente.add(txtCorreo);
        panelTransparente.add(btnGenerar);
        panelTransparente.add(lblMensaje);
        panelTransparente.add(scroll);
        panelTransparente.add(btnGuardar);
        panelTransparente.add(btnVolver);

        // Añadir panel transparente al contenedor principal
        getContentPane().add(panelTransparente);

        // Añadir la imagen de fondo y enviarla al fondo
        JLabel lblFondo = new JLabel(fondoIcon);
        lblFondo.setBounds(360, 11, 154, 130);
        panelTransparente.add(lblFondo);
        getContentPane().setComponentZOrder(lblFondo, getContentPane().getComponentCount() - 1);
    }

    // Genera el correo automáticamente con formato nombre.apellido@gmail.com
    private void generarCorreo() {
        String nombre = txtNombre.getText().trim().toLowerCase();
        String apellido = txtApellido.getText().trim().toLowerCase();
        if (!nombre.isEmpty() && !apellido.isEmpty()) {
            txtCorreo.setText(nombre + "." + apellido + "@gmail.com");
        } else {
            JOptionPane.showMessageDialog(this, "Rellena nombre y apellido.");
        }
    }

    // Guarda el mensaje en la base de datos, insertando cliente si no existe
    private void guardarEnBD() {
        String nombre = txtNombre.getText().trim();
        String apellido = txtApellido.getText().trim();
        String correo = txtCorreo.getText().trim();
        String mensaje = txtMensaje.getText().trim();

        if (correo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Primero debes generar el correo.");
            return;
        }

        if (mensaje.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, escribe un mensaje antes de enviarlo.");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Estás seguro de que quieres enviar este mensaje?",
                "Confirmación de envío",
                JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                ConexionMySQL conexion = new ConexionMySQL("root", "", "taller_repuestos");
                conexion.conectar();

                // Verificar si cliente existe
                String sqlSelect = "SELECT id FROM clientes WHERE correo = ?";
                PreparedStatement pstmt = conexion.getConexion().prepareStatement(sqlSelect);
                pstmt.setString(1, correo);
                ResultSet rs = pstmt.executeQuery();

                int clienteId;
                if (rs.next()) {
                    clienteId = rs.getInt("id");
                } else {
                    // Insertar cliente nuevo
                    String sqlInsert = "INSERT INTO clientes (nombre, apellidos, correo) VALUES (?, ?, ?)";
                    pstmt = conexion.getConexion().prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);
                    pstmt.setString(1, nombre);
                    pstmt.setString(2, apellido);
                    pstmt.setString(3, correo);
                    pstmt.executeUpdate();
                    rs = pstmt.getGeneratedKeys();
                    rs.next();
                    clienteId = rs.getInt(1);
                }
                rs.close();
                pstmt.close();

                // Llamar procedimiento almacenado correctamente con prepareCall
                String sql = "CALL RegistrarMensajeSoporte(?, ?)";
                CallableStatement cstmt = conexion.getConexion().prepareCall(sql);
                cstmt.setInt(1, clienteId);
                cstmt.setString(2, mensaje);
                cstmt.executeUpdate();
                cstmt.close();

                conexion.desconectar();

                JOptionPane.showMessageDialog(this, "Mensaje enviado correctamente.");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al guardar en la base de datos:\n" + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Envío cancelado.");
        }
    }

    // Vuelve al menú principal cerrando esta ventana
    private void volverAlMenu() {
        MenuInicio menu = new MenuInicio();
        menu.setVisible(true);
        dispose();
    }
}
