package TurboDesk; // Paquete al que pertenece esta clase

// Importa herramientas para crear interfaces gráficas
import javax.swing.*;
import java.awt.*;

public class MenuInicio extends JFrame { // Esta clase representa la ventana principal
    private static final long serialVersionUID = 1L; // ID para la serialización (puedes ignorarlo si no usas archivos)

    // Constructor: se ejecuta al crear un objeto de esta clase (la ventana)
    public MenuInicio() {
        // Establece el icono que aparece en la parte superior de la ventana
        setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Alumno1\\Downloads\\...jpg"));

        // Título que aparece en la ventana
        setTitle("Gestión de Taller de Coches - TurboDesk");

        // Tamaño de la ventana (ancho x alto)
        setSize(1340, 890);

        // Cierra el programa cuando se cierra esta ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Centra la ventana en el centro de la pantalla
        setLocationRelativeTo(null);

        // Crea un panel con botones y lo añade a la ventana
        JPanel panelBotones = getPanelBotones();

        // Establece un diseño con márgenes
        getContentPane().setLayout(new BorderLayout(20, 20));

        // Coloca el panel en el centro de la ventana
        getContentPane().add(panelBotones, BorderLayout.CENTER);
    }

    // Método que crea y devuelve un panel con los botones
    private JPanel getPanelBotones() {
        // Botón para acceder a la sección de Coches
        JButton btnCoches = new JButton("Coches");
        btnCoches.setForeground(Color.WHITE); // Color del texto
        btnCoches.setFont(new Font("Tahoma", Font.BOLD, 11)); // Fuente y estilo del texto
        btnCoches.setBackground(Color.BLACK); // Fondo del botón
        btnCoches.setBounds(127, 136, 113, 41); // Posición y tamaño del botón

        // Acción cuando se hace clic: abre la ventana Coches y cierra el menú
        btnCoches.addActionListener(e -> {
            Coches ventanaCoches = new Coches();
            ventanaCoches.setVisible(true); // Muestra la ventana de Coches
            dispose(); // Cierra esta ventana (el menú)
        });

        // Botón para acceder a la sección de Citas
        JButton btnCitas = new JButton("Citas");
        btnCitas.setForeground(Color.WHITE);
        btnCitas.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnCitas.setBackground(Color.BLACK);
        btnCitas.setBounds(127, 206, 113, 41);

        // Acción cuando se hace clic: abre la ventana NuevaCita y cierra el menú
        btnCitas.addActionListener(e -> {
            NuevaCita g = new NuevaCita();
            g.setVisible(true); // Muestra la ventana para crear nueva cita
            dispose(); // Cierra el menú
        });

        // Botón para acceder a la sección de Soporte
        JButton btnSoporte = new JButton("Soporte");
        btnSoporte.setForeground(Color.WHITE);
        btnSoporte.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnSoporte.setBackground(Color.BLACK);
        btnSoporte.setBounds(127, 277, 113, 41);

        // Acción cuando se hace clic: abre la ventana Soporte y cierra el menú
        btnSoporte.addActionListener(e -> {
            Soporte ventanaSoporte = new Soporte();
            ventanaSoporte.setVisible(true); // Muestra la ventana de Soporte
            dispose(); // Cierra el menú
        });

        // Crea el panel donde se colocarán los botones
        JPanel panelBotones = new JPanel();
        panelBotones.setBackground(Color.GRAY); // Color de fondo del panel
        panelBotones.setLayout(null); // Permite usar posiciones absolutas

        // Añade los tres botones al panel
        panelBotones.add(btnCoches);
        panelBotones.add(btnCitas);
        panelBotones.add(btnSoporte);

        // Añade una imagen de fondo (logo) al panel
        JLabel lblLogo = new JLabel();
        lblLogo.setIcon(new ImageIcon(MenuInicio.class.getResource("/TurboDesk/icono_repuestos.jpg"))); // Imagen del logo
        lblLogo.setBounds(-74, -59, 1450, 953); // Posición y tamaño del logo
        panelBotones.add(lblLogo); // Añade el logo al panel

        // Devuelve el panel completo con los botones y el logo
        return panelBotones;
    }

    // Método principal: se ejecuta al iniciar el programa
    public static void main(String[] args) {
        // Crea la ventana principal de forma segura para interfaces gráficas
        SwingUtilities.invokeLater(() -> {
            MenuInicio ventana = new MenuInicio(); // Crea la ventana
            ventana.setVisible(true); // Muestra la ventana en pantalla
        });
    }
}
