package com.empresa.tallercoches;

import javax.swing.*;
import java.awt.*;

public class MenuInicio extends JFrame {

    public MenuInicio() {
        // Configurar ventana
        setTitle("Gestión de Taller de Coches");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla

        // Crear componentes
        JLabel titulo = new JLabel("Inicio", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 26));

        JPanel panelBotones = getPanelBotones();

        // Añadir componentes a la ventana
        setLayout(new BorderLayout(20, 20));
        add(titulo, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
    }

    private JPanel getPanelBotones() {
        JButton btnRepuestos = new JButton("Repuestos");
        JButton btnCitas = new JButton("Citas");


        // Añadir eventos a cada botón
        btnRepuestos.addActionListener(e -> {
            VentanaRepuestos repuestos = new VentanaRepuestos();
            repuestos.setVisible(true);
            this.dispose(); // Cierra la ventana actual
        });

        btnCitas.addActionListener(e -> {
            VentanaCitas citas = new VentanaCitas();
            citas.setVisible(true);
            this.dispose(); // Cierra la ventana actual
        });

        // Panel para los botones
        JPanel panelBotones = new JPanel();
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));//botones
        panelBotones.add(btnRepuestos);
        panelBotones.add(btnCitas);


        return panelBotones;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuInicio ventana = new MenuInicio();
            ventana.setVisible(true);
        });
    }
}
