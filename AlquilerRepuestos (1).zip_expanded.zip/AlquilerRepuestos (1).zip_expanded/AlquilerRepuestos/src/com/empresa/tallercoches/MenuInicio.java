package com.empresa.tallercoches;

import javax.swing.*;
import java.awt.*;

public class MenuInicio extends JFrame {

    public MenuInicio() {
        // Configurar ventana
        setTitle("Gestión de Taller de Coches");
        setSize(1174, 890);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla

        JPanel panelBotones = getPanelBotones();

        // Añadir componentes a la ventana
        getContentPane().setLayout(new BorderLayout(20, 20));
        getContentPane().add(panelBotones, BorderLayout.CENTER);
    }

    private JPanel getPanelBotones() {
        JButton btnRepuestos = new JButton("Repuestos");
        btnRepuestos.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnRepuestos.setBackground(Color.BLACK);
        btnRepuestos.setBounds(266, 411, 113, 41);
        JButton btnCitas = new JButton("Citas");
        btnCitas.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnCitas.setBackground(Color.BLACK);
        btnCitas.setBounds(616, 411, 113, 41);


        // Añadir eventos a cada botón
        btnRepuestos.addActionListener(e -> {
            VentanaRepuestos repuestos = new VentanaRepuestos();
            repuestos.setVisible(true);
            this.dispose(); // Cierra la ventana actual
        });

        btnCitas.addActionListener(e -> {
            VentanaCitas citas = new VentanaCitas();
            citas.setVisible(true);
            this.dispose(); // Cierra la ventana actual
        });

        // Panel para los botones

        JPanel panelBotones = new JPanel();
        panelBotones.setBackground(Color.GRAY);
        panelBotones.setLayout(null);
        panelBotones.add(btnRepuestos);
        panelBotones.add(btnCitas);
                
                JLabel lblNewLabel = new JLabel("");
                lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Alumno1\\Pictures\\Screenshots\\Captura de pantalla 2025-04-30 142617.png"));
                lblNewLabel.setBounds(110, 22, 895, 335);
                panelBotones.add(lblNewLabel);
                
                JLabel lblNewLabel_1 = new JLabel("");
                lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Alumno1\\Pictures\\calendario.png"));
                lblNewLabel_1.setBounds(561, 501, 225, 201);
                panelBotones.add(lblNewLabel_1);
        return panelBotones;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuInicio ventana = new MenuInicio();
            ventana.setVisible(true);
        });

    }
}
