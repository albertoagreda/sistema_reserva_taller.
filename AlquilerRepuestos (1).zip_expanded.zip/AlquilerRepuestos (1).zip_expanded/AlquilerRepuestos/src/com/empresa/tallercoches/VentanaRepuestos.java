package com.empresa.tallercoches;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class VentanaRepuestos extends JFrame {

    public VentanaRepuestos() {
        setTitle("Gestión de Repuestos");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel titulo = new JLabel("Gestión de Repuestos", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 22));

        JButton btnBuscar = new JButton("Buscar Repuestos");
        JButton btnReservar = new JButton("Reservar Repuesto");

        //btnBuscar.addActionListener(e -> JOptionPane.showMessageDialog(this, "Buscar Repuestos"));
        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ConexionMySQL conexion=new ConexionMySQL("root","","taller_repuestos");
                try {
                    conexion.conectar();
                    String prueba="insert into coches(MODELO, ANIO, MARCA, DISPONIBLE, KILOMETRAJE, COCHE_ID)values('SEAT',2001,'Arona','Y',45,98)";
                    conexion.ejecutarInsertDeleteUpdate(prueba);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });;

        btnReservar.addActionListener(e -> JOptionPane.showMessageDialog(this, "Reservar Repuesto"));


        JPanel panelBotones = new JPanel(new GridLayout(3, 1, 15, 15));
        panelBotones.add(btnBuscar);
        panelBotones.add(btnReservar);

        setLayout(new BorderLayout(20, 20));
        add(titulo, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);

        JButton btnVolver = new JButton("⬅ Volver al Menú");
        btnVolver.addActionListener(e -> {
            MenuInicio menu = new MenuInicio();
            menu.setVisible(true);
            dispose(); // Cerrar esta ventana
        });
        panelBotones.add(btnVolver);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));//botones
    }


}
